from django.urls import path
from .views import *

urlpatterns = [
    # path('', home, name='home'),
    # path('login/', loginPage, name='login'),
    # path('logout/', logoutPage, name='logout'),

    # path('achievements/', achievementsPage, name='admin-achievements-page'),
    # path('add-achievement/', add_achievement, name='add-achievements-page'),
    # path('update-achievement/<int:pk>/', update_achievements, name='update-achievements-page'),
    # path('delete-achievement/<int:pk>/', delete_achievements, name='delete-achievements-page'),
    # path('delete-achievement-image/<int:pk>/', delete_achievement_image, name='delete-achievements-image'),

    # path('anniversary/', anniversaryPage, name='admin-anniversary-page'),
    # path('add-anniversary/', add_anniversary, name='add-anniversary-page'),
    # path('update-anniversary/<int:pk>/', update_anniversary, name='update-anniversary-page'),
    # path('delete-anniversary/<int:pk>/', delete_anniversary, name='delete-anniversary-page'),
    # path('delete-anniversary-image/<int:pk>/', delete_anniversary_image, name='delete-anniversary-image'),

    # path('event/', eventPage, name='admin-event-page'),
    # path('add-event/', add_event, name='add-event-page'),
    # path('update-event/<int:pk>/', update_event, name='update-event-page'),
    # path('delete-event/<int:pk>/', delete_event, name='delete-event-page'),
    # path('delete-event-image/<int:pk>/', delete_event_image, name='delete-event-image'),

    # path('notice/', noticePage, name='admin-notice-page'),
    # path('add-notice/', add_notice, name='add-notice-page'),
    # path('update-notice/<int:pk>/', update_notice, name='update-notice-page'),
    # path('delete-notice/<int:pk>/', delete_notice, name='delete-notice-page'),
    
    # path('social/', socialPage, name='admin-social-page'),
    # path('add-social/', add_social, name='add-social-page'),
    # path('update-social/<int:pk>/', update_social, name='update-social-page'),
    # path('delete-social/<int:pk>/', delete_social, name='delete-social-page'),
    # path('delete-social-image/<int:pk>/', delete_social_image, name='delete-social-image'),

    # path('testimonial/', testimonialPage, name='admin-testimonial-page'),
    # path('add-testimonial/', add_testimonial, name='add-testimonial-page'),
    # path('update-testimonial/<int:pk>/', update_testimonial, name='update-testimonial-page'),
    # path('delete-testimonial/<int:pk>/', delete_testimonial, name='delete-testimonial-page'),
]

