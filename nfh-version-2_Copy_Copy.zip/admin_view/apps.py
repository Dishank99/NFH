from django.apps import AppConfig


class AdminViewConfig(AppConfig):
    name = 'admin_view'
